import React, { useEffect, useRef } from "react";
import type { ViewStyle, FlatListProps } from "react-native";
import { StyleSheet, View, AccessibilityInfo } from "react-native";
import Animated, { FadeInUp, SlideInLeft, SlideInRight, useSharedValue, useAnimatedStyle, withSpring } from "react-native-reanimated";

const usePrefersReducedMotion = () => {
  const reduced = useRef(false);
  useEffect(() => {
    AccessibilityInfo.isReduceMotionEnabled().then(v => { reduced.current = !!v; });
  }, []);
  return reduced;
};

interface StaggeredFadeInUpListProps {
  children: React.ReactNode[];
  delay?: number;
  style?: ViewStyle;
  containerStyle?: ViewStyle;
}

export const StaggeredFadeInUpList: React.FC<StaggeredFadeInUpListProps> = ({
  children,
  delay = 100,
  style,
  containerStyle,
}) => {
  const reduceMotionRef = useRef(false);
  useEffect(() => { AccessibilityInfo.isReduceMotionEnabled().then(v => { reduceMotionRef.current = !!v; }); }, []);

  return (
    <View style={StyleSheet.flatten([containerStyle])}>
      {children.map((child, index) => {
        return (
          <Animated.View
            key={index}
            entering={reduceMotionRef.current ? undefined : FadeInUp.delay(index * delay).springify().damping(25).stiffness(300)}
            style={style}
          >
            {child}
          </Animated.View>
        );
      })}
    </View>
  );
};

interface PhysicsBasedScaleInProps {
  children: React.ReactNode;
  delay?: number;
  style?: ViewStyle;
  trigger?: boolean;
}

export const PhysicsBasedScaleIn: React.FC<PhysicsBasedScaleInProps> = ({
  children,
  delay = 0,
  style,
  trigger = true,
}) => {
  const s = useSharedValue(0.3);
  const reduceMotionRef = useRef(false);
  useEffect(() => { AccessibilityInfo.isReduceMotionEnabled().then(v => { reduceMotionRef.current = !!v; }); }, []);

  useEffect(() => {
    if (trigger) {
      s.value = withSpring(1, { damping: 10, stiffness: 600, mass: 0.5 });
    }
  }, [trigger]);

  const styleA = useAnimatedStyle(() => ({
    opacity: reduceMotionRef.current ? 1 : s.value,
    transform: [{ scale: reduceMotionRef.current ? 1 : s.value }],
  }));
  return <Animated.View style={[styleA, style]}>{children}</Animated.View>;
};

interface PageTransitionProps {
  children: React.ReactNode;
  type?: "fade" | "slideLeft" | "slideRight";
  duration?: number;
  style?: ViewStyle;
}

export const PageTransition: React.FC<PageTransitionProps> = ({
  children,
  type = "fade",
  duration = 300,
  style,
}) => {
  const entering =
    type === "fade"
      ? FadeInUp.duration(duration)
      : type === "slideLeft"
      ? SlideInLeft.duration(duration)
      : type === "slideRight"
      ? SlideInRight.duration(duration)
      : FadeInUp.duration(duration);
  return <Animated.View entering={entering} style={style}>{children}</Animated.View>;
};

interface GestureWrapperProps {
  children: React.ReactNode;
  style?: ViewStyle;
}

export const GestureWrapper: React.FC<GestureWrapperProps> = ({
  children,
  style,
}) => {
  return <View style={style}>{children}</View>;
}

export default {
  StaggeredFadeInUpList,
  PhysicsBasedScaleIn,
  PageTransition,
  GestureWrapper,
};
