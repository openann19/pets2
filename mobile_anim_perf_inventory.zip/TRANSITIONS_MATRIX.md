# Navigation Transitions Matrix

| Route | File | Type |
|-------|------|------|
| - | `src/navigation/types.ts` |   screenOptions?: ScreenOptions;... |
| - | `src/navigation/types.ts` |   screenOptions: ScreenOptions;... |
| - | `src/navigation/AdminNavigator.tsx` |       screenOptions={{... |
| - | `src/App.tsx` |     screenOptions={{ headerShown: false }}... |
