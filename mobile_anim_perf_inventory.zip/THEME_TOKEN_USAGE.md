# Theme & Token Usage

## Color Usage
- Hardcoded Colors Found: 274
- Files Using Tokens: 116
- Token vs Hardcoded Ratio: 0.42

## Top Hardcoded Colors

- `#ec4899` - used in 44 files
- `#FFFFFF` - used in 41 files
- `#6B7280` - used in 35 files
- `#EF4444` - used in 34 files
- `#8B5CF6` - used in 30 files
- `#10B981` - used in 27 files
- `#6b7280` - used in 23 files
- `#374151` - used in 23 files
- `#1f2937` - used in 20 files
- `#111827` - used in 20 files
- `#ef4444` - used in 20 files
- `#3B82F6` - used in 19 files
- `#e5e7eb` - used in 18 files
- `#10b981` - used in 17 files
- `#F3F4F6` - used in 17 files
- `#f8f9fa` - used in 16 files
- `#F59E0B` - used in 16 files
- `#000000` - used in 15 files
- `#f3f4f6` - used in 14 files
- `#9CA3AF` - used in 13 files
