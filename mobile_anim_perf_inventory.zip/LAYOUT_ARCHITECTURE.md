# Layout Architecture

## Large Components (>200 LOC)

| File | Lines | Component |
|------|-------|-----------|
